<?php
$template_arr=array(
	array(
		'id'=>'template1',
		'title'=>'Shipping Label 1',
		'preview_img'=>'template1.png',
	),
);
//$template_header='data.template_header.php';
//$template_footer='data.template_footer.php';